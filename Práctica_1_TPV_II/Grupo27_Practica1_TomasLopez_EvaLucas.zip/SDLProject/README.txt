
This template already includes all SDL libraries. You can start using
it for you assignments, etc.


If you want to create your own new project do the following:

 - Create your new project in Visual Studio

 - Copy the following directories directories from this template to
   your project

    bin/
    SDL2-2.0.7/
    SDL2_mixer-2.0.2/
    SDL2_ttf-2.0.14/  
    SDL2_image-2.0.1/
    SDL2_net-2.0.1/

 - In Visual Studio, go to View -> Other Windows -> Property Manager
 
 - Select "Add Existing Property Sheet", and then select the file
   SDLProject.props from this template
 
 - You are done!


