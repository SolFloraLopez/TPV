#pragma once

struct Component {
};

